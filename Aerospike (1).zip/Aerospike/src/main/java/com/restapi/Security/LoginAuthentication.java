//package com.restapi.Security;
//
//import com.restapi.Model.Person;
//import com.restapi.Repository.PersonRepositoryIml;
//import io.micronaut.core.annotation.Nullable;
//import io.micronaut.http.HttpRequest;
//import io.micronaut.security.authentication.AuthenticationProvider;
////import io.micronaut.security.authentication.AuthenticationRequest;
//import io.micronaut.security.authentication.AuthenticationRequest;
//import io.micronaut.security.authentication.AuthenticationResponse;
//import jakarta.inject.Inject;
//import jakarta.inject.Singleton;
//import org.reactivestreams.Publisher;
//import reactor.core.publisher.Flux;
//import reactor.core.publisher.FluxSink;
//
//import java.util.Collections;
//
//@Singleton
//public class LoginAuthentication implements AuthenticationProvider {
//    @Inject
//    PersonRepositoryIml personRepositoryIml;
//
//    @Override
//    public Publisher<AuthenticationResponse> authenticate(AuthenticationRequest authenticationRequest) {
//        return null;
//    }
//
//    @Override
//    public Publisher<AuthenticationResponse> authenticate(@Nullable HttpRequest<?> httpRequest, AuthenticationRequest<?, ?> authenticationRequest) {
//        return Flux.create(emitter -> {
//            Object identity = authenticationRequest.getIdentity();
//            Object secret = authenticationRequest.getSecret();
//            Person person = PersonRepositoryIml.findByEmail(identity.toString());
//            boolean validateCredentials = person != null && person.getPassword().equals(secret);
//            System.out.println(validateCredentials);
//            if (validateCredentials) {
//                emitter.next(AuthenticationResponse.success(identity.toString()));
//
//                emitter.complete();
//            } else {
//                emitter.error(AuthenticationResponse.exception());
//            }
//        }, FluxSink.OverflowStrategy.ERROR);
//    }
//}
